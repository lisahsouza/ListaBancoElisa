CREATE DATABASE pratica05;

CREATE TABLE dados_multimidia (
codigo INT AUTO_INCREMENT NOT NULL,
nome VARCHAR(30), 
tipo VARCHAR (20),
dados LONGBLOB,
PRIMARY KEY (codigo)
);

INSERT INTO dados_multimidia (nome, tipo, dados) VALUES 
('computador', 'jpg', LOAD_FILE("C:\\wamp64\\tmp\\computador2")),
('computador1', 'jfif', LOAD_FILE("C:\\wamp64\\tmp\\computador3")),
('computador2', 'jpg', LOAD_FILE ("C:\\wamp64\\tmp\\imagem_export.jpg"));

SELECT * FROM dados_multimidia;

SHOW VARIABLES LIKE "secure_file_priv"; 

SELECT dados INTO OUTFILE 'C:\\Program Files\\MySQL\\ MySQL Server 5.7\\Uploads\\imagem_export.jpg'
FROM dados_multimidia 
WHERE codigo = 3;
