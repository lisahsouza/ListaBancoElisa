CREATE DATABASE pratica6;

SELECT * FROM exemplo1;

SELECT * FROM exemplo1 
WHERE c3 = 4801 AND c2 = 4899 AND c4 = 4750;
/*0.063 seg */

CREATE INDEX idx_c2 ON exemplo1 (c2);
CREATE INDEX idx_c3 ON exemplo1 (c3);
CREATE INDEX idx_c4 ON exemplo1 (c4);

ANALYZE TABLE exemplo1;

SELECT * FROM exemplo1 
WHERE c3 = 4801 AND c2 = 4899 AND c4 = 4750;
/*0.000 seg */

SELECT * FROM exemplo1 WHERE c1 = 5020;
/*0.265 seg */

SELECT * FROM exemplo1 WHERE c2 = 5020;
/*0.015 seg */